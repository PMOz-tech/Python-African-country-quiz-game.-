import random


def get_africap_statements():
    statements = [ [ 'Algeria' , "Algiers" ] , [ 'Angola' , "Luanda" ] , [ 'Benin' , "Porto-Novo" ] , [ 'Botswana' , "Gaborone" ] ,
                   [ 'Burkina Faso' , "Ouagadougou" ] , [ 'Burundi' , "Bujumbura" ] , [ 'Cameroon' , "Yaounde" ] , [ "The Republic of Cabo Verde" , 'Praia' ] ,
                   [ 'The Central African Republic' , "Bangui" ] , [ 'Chad' , "N'Djamena" ] , [ 'Comoros' , "Moroni" ] , [ 'Democratic Republic of Congo' , "Kinshasa" ] ,
                   [ 'Republic of Congo' , "Brazzaville" ] , [ "Cote d'Ivoire" , "Yamoussoukro" ] , [ 'Djibouti' , "Djibouti" ] , [ 'Egypt' , "Cairo" ] , [ 'Equatorial Guinea' , "Malabo" ] ,
                   [ 'Eritrea' , "Asmara" ], [ 'Ethiopia' , "Addis Ababa" ] , [ 'Gabon' , "Libreville" ] , [ 'Gambia' , "Banjul" ] ,
                   [ 'Ghana' , "Accra" ] , [ 'Guinea' , "Conakry" ] , [ 'Guinea-Bissau' , "Bissau" ] , [ 'Kenya' , "Nairobi" ] ,
                   [ 'Lesotho' , "Maseru" ] , [ 'Liberia' , "Monrovia" ] , [ 'Libya' , "Tripoli" ] ,
                   [ 'Madagascar' , "Antananarivo" ] , [ 'Malawi' , "Lilongwe" ] , [ 'Mali' , "Bamako" ] ,
                   [ 'Mauritania' , "Nouakchott" ] , [ 'Mauritius' , "Port Louis" ] , [ 'Morocco' , "Rabat" ] ,
                   [ 'Mozambique' , "Maputo" ] , [ 'Namibia' , "Windhoek" ] , [ 'Niger' , "Niamey" ] , [ 'Nigeria' , "Abuja" ] , [ 'Rwanda' , "Kigali" ] ,
                   [ 'Republic Arab Saharawi Democratic' , "Aauin" ] , [ 'Sao Tome' , 'Principe' , "Sao Tome" ] ,
                   [ 'Senegal' , "Dakar" ] , [ 'Seychelles' , "Victoria" ] , [ 'Sierra Leone' , "Freetown" ] , [ 'Somalia' , "Mogadishu" ] ,
                   [ 'South Africa' , "Pretoria" , "Bloemfontein" , "CapeTown" ] ,
                   [ 'South Sudan' , "Juba" ] , [ 'Sudan' , "Khartoum" ] , [ 'Swaziland' , "Lobamba" , "Mbabane" ] ,
                   [ 'Tanzania' , "Dar es Salaam" , "Dodoma" ] , [ 'Togo' , "Lome" ] , [ 'Tunisia' , "Tunis" ] ,
                   [ 'Uganda' , "Kampala]" ,[ 'Zambia' , "Lusaka" ] , [ 'Zimbabwe' , "Harare" ] ] ]

    return statements


def play_africap_quiz():
    africap_statements = get_africap_statements()

    random.shuffle(africap_statements)

    score = 0

    for s in africap_statements:
        print("What is the capital " + s[ 0 ] + "?")
        answer = (input("Your answer is : ").lower().title())

        if answer == s[ 1 ]:
            print("Correct!!")
            score = score + 5

        else:
            print("Incorrect" + " " + "The correct answer is" + " " + s[ 1 ])

    print("Your final score is: " + str(score))


def main_menu():
    print("+----------------------------------------------------------------------------+")
    print("|               Welcome To African Countries Quiz                            |")
    print("+----------------------------------------------------------------------------+")
    print("|                Choose From The Main Menu Below                             |")
    print("|                                                                            |")
    print("| 1.                          Start Quiz                                     |")
    print("| 0.                           Quit                                          |")
    print("+----------------------------------------------------------------------------+")

    choice = input("Enter 1 or 0: ")
    if choice == "1":
        play_africap_quiz()
    elif choice == "0":
        print("Thanks for playing!!!")
        quit()


main_menu()
