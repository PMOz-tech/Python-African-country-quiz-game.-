import csv

with open('african_countries.csv', 'r') as f:
    file= csv.reader(f)
    my_list = list(file)
    print(my_list)

    index = my_list[1]
    print(index)

