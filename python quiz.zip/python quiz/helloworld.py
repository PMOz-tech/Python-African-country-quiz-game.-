import csv
import random

with open('african_countries.csv', 'r') as f:
    file= csv.reader(f)
    my_list = list(file)
    print(my_list)



def get_africap_statements():
 statements = my_list
 return statements

def play_africap_quiz():
    africap_statements = get_africap_statements()

    random.shuffle(africap_statements)

    score = 0

    for s in africap_statements:
        print("What is the capital " + s[ 0 ] + "?")
        answer = (input("Your answer is : ").lower().title())

        if answer==s[ 1 ]:
            print("Correct!!")
            score = score + 5

        else:
            print("Incorrect" + " " + "The correct answer is" + " " + s[ 1 ])

    print("Your final score is: " + str(score))

def main_menu():
    print("+----------------------------------------------------------------------------+")
    print("|               Welcome To African Countries Quiz                            |")
    print("+----------------------------------------------------------------------------+")
    print("|                Choose From The Main Menu Below                             |")
    print("|                                                                            |")
    print("| 1.                          Start Quiz                                     |")
    print("| 0.                           Quit                                          |")
    print("+----------------------------------------------------------------------------+")

    choice = input("Enter 1 or 0: ")
    if choice == "1":
        play_africap_quiz()
    elif choice == "0":
        print("Thanks for playing!!!")
        quit()


main_menu()